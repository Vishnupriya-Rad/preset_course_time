<?php
defined('MOODLE_INTERNAL') || die();

$plugin->component = 'local_time_analysis';
$plugin->version = 2025040200; // Plugin version
$plugin->requires = 2021051700; // Moodle 3.11 or later
$plugin->maturity = MATURITY_STABLE;
$plugin->release = '1.0';
