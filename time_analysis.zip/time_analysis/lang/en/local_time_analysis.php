<?php
$string['pluginname'] = 'Time Analysis';
$string['manage_time'] = 'Manage Course Time Requirements';
