
<?php
defined('MOODLE_INTERNAL') || die();

function xmldb_local_time_analysis_upgrade($oldversion) {
    global $DB;

    $dbman = $DB->get_manager();

    if ($oldversion < 2025040200) {
        // Define the mdl_time table structure.
        $table = new xmldb_table('mdl_time');

        // Adding fields.
        $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
        $table->add_field('course_id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
        $table->add_field('category_id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
        $table->add_field('time_to_spent', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
        $table->add_field('created_at', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
        $table->add_field('updated_at', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);

        // Adding keys.
        $table->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);
        $table->add_key('course_fk', XMLDB_KEY_FOREIGN, ['course_id'], 'course', ['id']);
        $table->add_key('category_fk', XMLDB_KEY_FOREIGN, ['category_id'], 'course_categories', ['id']);

        // If the table doesn’t exist, create it.
        if (!$dbman->table_exists($table)) {
            $dbman->create_table($table);
        }

        // Update the version in Moodle's DB.
        upgrade_plugin_savepoint(true, 2025040200, 'local', 'time_analysis');
    }

    return true;
}
